package com.example.mobile.API;

import com.example.mobile.ModelData.Object;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

//fungsi untuk menyaring API
public interface Service {
    @GET("indonesia/provinsi")
    Call<List<Object>> getProvinsi();
}
