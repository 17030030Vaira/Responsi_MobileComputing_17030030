package com.example.mobile.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mobile.Detail;
import com.example.mobile.ModelData.Attributes;
import com.example.mobile.ModelData.Object;
import com.example.mobile.R;

import java.util.List;

public class AdapterList extends RecyclerView.Adapter<AdapterList.ViewHolder> {

    Context context;
    List<Object> objectList;

    public AdapterList(Context context, List<Object> objectList) {
        this.context = context;
        this.objectList = objectList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //inisialisasi layout untuk menampilkan data
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        //inisialisasi Model data sesuai respon dari API
        Attributes attributes = objectList.get(position).getAttributes();

        //menampilkan data yang didapatkan pada setiap elemen View / Tampilan
        holder.nama.setText(attributes.getProvinsi());
        holder.smbh.setText(attributes.getKasus_Semb());
        holder.posit.setText(attributes.getKasus_Posi());
        holder.meni.setText(attributes.getKasus_Meni());

        //fungsi untuk menjalankan perintah saat List item dipilih atau diclick
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //inisialisasi activity baru
                Intent intent = new Intent(context, Detail.class);
                //fungsi untuk membawa data yang telah dipilih ke Activity yang dituju
                intent.putExtra("NamaProv",attributes.getProvinsi());
                intent.putExtra("Sembuh",attributes.getKasus_Semb());
                intent.putExtra("Positif",attributes.getKasus_Posi());
                intent.putExtra("Meninggal",attributes.getKasus_Meni());
                //mamanggil activity
                context.startActivity(intent);
            }
        });
    }

    //fungsi untuk menampilkan jumlah list sesuai jumlah data
    @Override
    public int getItemCount() {
        return objectList.size();
    }

    //inisialisasi setiap komponen View / Tampilan List
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nama;
        TextView smbh;
        TextView posit;
        TextView meni;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nama = itemView.findViewById(R.id.namaProv);
            smbh = itemView.findViewById(R.id.sembuh);
            posit = itemView.findViewById(R.id.positif);
            meni = itemView.findViewById(R.id.meninggal);
            cardView = itemView.findViewById(R.id.cardview);
        }
    }
}
