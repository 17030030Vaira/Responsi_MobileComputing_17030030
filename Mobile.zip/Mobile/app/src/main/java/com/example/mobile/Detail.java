package com.example.mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Detail extends AppCompatActivity {

    TextView nama,smbh,posit,meni;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //inisialisasi komponen View
        nama = findViewById(R.id.namaprovdet);
        smbh = findViewById(R.id.txsemdet);
        posit = findViewById(R.id.txposidet);
        meni = findViewById(R.id.txmenidet);

        //menangkap data yang dibawa dari activity sebelumnya
        Intent intent = getIntent();
        String namaProv = intent.getStringExtra("NamaProv");
        String sembuh = intent.getStringExtra("Sembuh");
        String positif = intent.getStringExtra("Positif");
        String meninggal = intent.getStringExtra("Meninggal");

        //menampilkan data yang dibawa
        nama.setText(namaProv);
        smbh.setText(sembuh+" Jiwa");
        posit.setText(positif+" Jiwa");
        meni.setText(meninggal+" Jiwa");
    }

    //method untuk perintah tombol kembali dari device user
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}