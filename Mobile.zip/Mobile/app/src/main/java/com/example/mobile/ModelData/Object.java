package com.example.mobile.ModelData;

public class Object {
    Attributes attributes;

    public Attributes getAttributes() {
        return this.attributes;
    }
}
